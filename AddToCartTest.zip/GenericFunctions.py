from selenium import webdriver
from selenium.common import NoAlertPresentException
from selenium.webdriver.common.by import By

class GenericFunc:
    def login(self, userName, password, driver):
        driver.find_element(By.ID, "user-name").send_keys(userName)
        driver.find_element(By.ID, "password").send_keys(password)
        driver.find_element(By.ID, "login-button").click()
        try:
            alert = driver.switch_to.alert
            # Optionally accept or dismiss the change password alert
            alert.accept()
        except NoAlertPresentException:
            print("No alert is present.")

    def logout(self, driver):
        driver.find_element(By.XPATH, "//button[text()='Open Menu']").click()
        # Click on the "Logout" link
        driver.find_element(By.LINK_TEXT, "Logout").click()
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

from GenericFunctions import GenericFunc

driver = None
def setup_module(module):
    global driver

    options = Options()

    prefs = {
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False
    }
    options.add_experimental_option("prefs", prefs)

    # Optional: Run in incognito mode
    options.add_argument("--incognito")

    # Initialize WebDriver with the configured options
    driver = webdriver.Chrome(options=options)

    driver.get("https://www.saucedemo.com/")
    driver.implicitly_wait(20)
    driver.maximize_window()


def teardown_module(module):
    driver.close()

def test_verifyAddToCart():
    genericFun = GenericFunc();
    genericFun.login("standard_user", "secret_sauce", driver)
    title = driver.find_element(By.CSS_SELECTOR, "div[class='app_logo']").text
    assert title == "Swag Labs", "Title not same"
    driver.find_element(By.CSS_SELECTOR, "button[id*='add-to-cart']").click()
    driver.find_element(By.CSS_SELECTOR, "a[class ='shopping_cart_link']").click()
    itemAdded = driver.find_element(By.CSS_SELECTOR, "div[class ='cart_quantity']").text
    assert  itemAdded == "1", "Item not added"
    driver.find_element(By.CSS_SELECTOR, "button[id ^= 'remove']").click()
    genericFun.logout(driver)

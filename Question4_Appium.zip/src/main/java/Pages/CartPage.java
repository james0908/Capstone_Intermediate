package Pages;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CartPage {

    AndroidDriver driver;

    public CartPage(AndroidDriver driver) {
        this.driver = driver;
    }

    public WebElement getCheckoutButton() {
        return driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"test-CHECKOUT\"]"));
    }

    public void clickCheckout(){
        getCheckoutButton().click();
    }
}

package Pages;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;

public class CheckoutPage {
    AndroidDriver driver;

    public CheckoutPage(AndroidDriver driver) {
        this.driver = driver;
    }

    public WebElement getRemoveBtn() {
        return driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text=\"REMOVE\"]"));
    }

   public WebElement getFirstNameInput() {
        return driver.findElement(AppiumBy.xpath("//android.widget.EditText[@content-desc=\"test-First Name\"]"));
    }
    public WebElement getLastNameInput() {

        return driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().descriptionContains(\"Last\")"));
    }
    public WebElement getZipCodeInput() {
        return driver.findElement(AppiumBy.xpath("//android.widget.EditText[@content-desc=\"test-Zip/Postal Code\"]"));
    }
    public WebElement getContinueBtn() {
        return driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"test-CONTINUE\"]"));
    }
    public WebElement getFinishBtn() {
        driver.findElement(
                AppiumBy.androidUIAutomator(
                        "new UiScrollable(new UiSelector().scrollable(true))" +
                                ".scrollIntoView(new UiSelector().text(\"FINISH\"))"
                )
        );
        return driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"test-FINISH\"]"));
    }


    public void enterCheckoutDetails(String fName, String lName, String zip) throws InterruptedException, IOException {
        getFirstNameInput().sendKeys(fName);
        getLastNameInput().sendKeys(lName);
        getZipCodeInput().sendKeys(zip);
        getContinueBtn().click();
        Thread.sleep(2000);
    }
    public void clickFinishBtn(){
        getFinishBtn().click();
    }

    public boolean itemExist(String itemName) throws InterruptedException {
        boolean isElementPresent;

        try {
            Thread.sleep(4000);
            isElementPresent = driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text=\"" + itemName + "\"]")).isDisplayed();
            System.out.println(isElementPresent);
        }
        catch (NoSuchElementException ex){
            isElementPresent = false;
        }
        return isElementPresent;
    }

    public void clickRemove() throws InterruptedException {
        getRemoveBtn().click();
        Thread.sleep(3000);
    }

    public boolean removeBtnNotPresent() throws InterruptedException {
        boolean isElementPresent = true;

        try {
            Thread.sleep(4000);
            isElementPresent = getRemoveBtn().isDisplayed();
        }
        catch (NoSuchElementException ex){
            isElementPresent = false;
        }
        return isElementPresent;
    }

}

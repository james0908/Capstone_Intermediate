package Pages;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class ProductsPage {

    AndroidDriver driver;

    public ProductsPage(AndroidDriver driver) {
        this.driver = driver;
    }

    public WebElement getAddToCrtButton() {
        return driver.findElement(AppiumBy.xpath("(//android.widget.TextView[@text=\"ADD TO CART\"])[1]"));
    }

    public WebElement getCrtButton() {
        return driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"test-Cart\"]/android.view.ViewGroup/android.widget.ImageView"));
    }

    public void clickAddToCart(){
        getAddToCrtButton().click();
    }

    public WebElement getMenu() {
        return driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"test-Menu\"]/android.view.ViewGroup/android.widget.ImageView"));
    }
    public WebElement getLogout() {
        return driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text=\"LOGOUT\"]"));
    }
    public WebElement filterBtn() {
        return driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"test-Modal Selector Button\"]/android.view.ViewGroup/android.view.ViewGroup/android.widget.ImageView"));
    }

    public  List<WebElement> getProductLinks(){
        return driver.findElements(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"test-Item title\"]"));
    }

    public void clickCart(){
        getCrtButton().click();
    }
    public void clickLogout(){
        getMenu().click();
        getLogout().click();
    }
    public void clickFilterBtn(){
        filterBtn().click();
    }
    public WebElement getItemName() {
        return driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"test-Item title\"]"));
    }

    public List<String> getAllLinkText(){
        List<String> listOfLinkText = new ArrayList<>();
        List<WebElement> listOfLinks = getProductLinks();
        for (WebElement element : listOfLinks) {
            String linkText = element.getText().trim(); // trim to remove extra whitespace
            listOfLinkText.add(linkText);
        }
        return listOfLinkText;
    }
    public String itemName(){
        return getItemName().getText();
    }
}

package Pages;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class OrderConfirmationPage {
    AndroidDriver driver;

    public OrderConfirmationPage(AndroidDriver driver) {
        this.driver = driver;
    }

    public WebElement getOrdertext() {
        return driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text=\"THANK YOU FOR YOU ORDER\"]"));
    }

    public String getConfirmationText(){
        return getOrdertext().getText();
    }
}

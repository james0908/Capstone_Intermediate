package Pages;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SortingPage {
    AndroidDriver driver;

    public SortingPage(AndroidDriver driver) {
        this.driver = driver;
    }

    public WebElement sortDescButton() {
        return driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text=\"Name (Z to A)\"]"));
    }

    public void clickSort(){
        sortDescButton().click();
    }
}

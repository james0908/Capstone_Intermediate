package Tests;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.testng.annotations.*;
import utils.ReadData;

import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.Map;

public class Base {
    AndroidDriver driver;
    @BeforeClass
    @Parameters("DeviceName")
    public void setup(String deviceName) throws IOException {
        String[][] data = ReadData.getData("TestData.xlsx", deviceName);
        UiAutomator2Options options = new UiAutomator2Options();
        options.setDeviceName(data[1][0]);
        options.setUdid(data[1][1]);
        options.setPlatformName(data[1][2]);
        options.setPlatformVersion(data[1][3]);
        options.setAppPackage("com.swaglabsmobileapp");
        options.setAppActivity("com.swaglabsmobileapp.SplashActivity");
        options.amend("ignoreHiddenApiPolicyError", true);
        options.setNoReset(true);
        options.setCapability("disableWindowAnimation", true);
        options.setCapability("autoGrantPermissions", true);

        URL url = new URL("http://127.0.0.1:4723");
        driver = new AndroidDriver(url,options);
        System.out.println("App started");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    }

    @AfterClass
    public void tearDown(){
        driver.executeScript("mobile: terminateApp", Map.of("appId", "com.swaglabsmobileapp"));
    }
}

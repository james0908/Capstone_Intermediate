package Tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.ProductsPage;
import pages.SortingPage;
import utils.ReadData;

import java.io.IOException;
import java.util.List;

public class SortingTest extends Base{

    @Test
    public void verifySorting() throws IOException {
        LoginPage lp = new LoginPage(driver);
        ProductsPage pp = new ProductsPage(driver);
        SortingPage sp = new SortingPage(driver);

        String[][] data = ReadData.getData("TestData.xlsx", "TestData");
        for (int i = 1; i< data.length; i++) {
            lp.login(data[i][0], data[i][1]);
            pp.clickFilterBtn();
            sp.clickSort();
            List<String> allLinks = pp.getAllLinkText();
            Assert.assertTrue(isSortedDescending(allLinks));
            pp.clickLogout();
        }
    }
    public static boolean isSortedDescending(List<String> list) {
        for (int i = 0; i < list.size() - 1; i++) {
            // Compare current element with the next one
            if (list.get(i).compareTo(list.get(i + 1)) < 0) {
                return false; // Not in descending order
            }
        }
        return true; // All elements are in descending order
    }
}

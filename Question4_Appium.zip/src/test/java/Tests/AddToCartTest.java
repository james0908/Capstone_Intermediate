package Tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;
import utils.ReadData;

import java.io.IOException;

public class AddToCartTest extends Base{

    @Test
    public void verifyAddToCart() throws InterruptedException, IOException {
        LoginPage lp = new LoginPage(driver);
        ProductsPage pp = new ProductsPage(driver);
        CartPage cp = new CartPage(driver);
        CheckoutPage co = new CheckoutPage(driver);
        OrderConfirmationPage oc = new OrderConfirmationPage(driver);

        String[][] data = ReadData.getData("TestData.xlsx", "TestData");
        for (int i = 1; i< data.length; i++) {
            lp.login(data[i][0], data[i][1]);
            pp.clickAddToCart();
            String itemAdded = pp.itemName();
            System.out.println(itemAdded);
            pp.clickCart();
            Thread.sleep(3000);
            Assert.assertTrue(co.itemExist(itemAdded));
            co.clickRemove();
            pp.clickLogout();
        }
    }
}

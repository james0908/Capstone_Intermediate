package Tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;
import utils.ReadData;

import java.io.IOException;

public class PlaceOrderTest extends Base {
    @Test
    public void verifyPlaceOrder() throws InterruptedException, IOException {
        LoginPage lp = new LoginPage(driver);
        ProductsPage pp = new ProductsPage(driver);
        CartPage cp = new CartPage(driver);
        CheckoutPage co = new CheckoutPage(driver);
        OrderConfirmationPage oc = new OrderConfirmationPage(driver);

        String[][] data = ReadData.getData("TestData.xlsx", "TestData");
        for (int i = 1; i< data.length; i++) {
            lp.login(data[i][0], data[i][1]);
            pp.clickAddToCart();
            pp.clickCart();
            Thread.sleep(3000);
            cp.clickCheckout();
            co.enterCheckoutDetails(data[i][2], data[i][3], data[i][4]);
            co.clickFinishBtn();
            String actualText = oc.getConfirmationText();
            String expectedText = "THANK YOU FOR YOU ORDER";
            Assert.assertEquals(actualText, expectedText);
            pp.clickLogout();
        }
    }
}
